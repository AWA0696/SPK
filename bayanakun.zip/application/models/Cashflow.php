<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cashflow extends CI_Model
{
	// public function getCashflow()
	// {
	// 	$this->db->select("akt_transaksi.tanggal, akt_transaksi.transaksi, akt_cashflow.tipe, akt_transaksi.jumlah");
	// 	$this->db->from("akt_transaksi");
	// 	$this->db->join("akt_cashflow", "akt_transaksi.id = akt_cashflow.id_transaksi");

	// 	return $this->db->get()->result();
	// }

	public function getCashflow()
	{

	}

	public function laporanCashFlow($tahun, $bulan)
	{
		return $this->db->query("SELECT akt_cashflow_analisys.cashflow, SUM(akt_rosetta_stone.jumlah) AS 'jumlah' FROM akt_cashflow_analisys LEFT JOIN akt_rosetta_stone ON akt_rosetta_stone.id = akt_cashflow_analisys.id_rosetta_stone WHERE YEAR(akt_rosetta_stone.tanggal) = '$tahun' AND MONTH(akt_rosetta_stone.tanggal) = '$bulan' GROUP BY akt_cashflow_analisys.cashflow ORDER BY akt_cashflow_analisys.cashflow ASC")->result();
	}

	public function cashflowReport($tahun, $bulan)
	{
		return $this->db->query("
			SELECT akt_cashflow.tipe, SUM(akt_transaksi.jumlah) AS 'jumlah' FROM akt_cashflow LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_cashflow.id_transaksi WHERE YEAR(akt_transaksi.tanggal) = '$tahun' AND MONTH(akt_transaksi.tanggal) = '$bulan' GROUP BY akt_cashflow.tipe ORDER BY akt_cashflow.tipe
		")->result();
	}

	public function rekapCashflow()
	{
		return $this->db->query("
			SELECT akt_cashflow.tipe,SUM(akt_transaksi.jumlah) AS 'jumlah' FROM akt_cashflow
			LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_cashflow.id_transaksi
			GROUP BY akt_cashflow.tipe
		")->result_array();
	}

	// 2021-4-9
	public function allCashflow()
	{
		return $this->db->query("SELECT akt_transaksi.tanggal, akt_transaksi.transaksi, akt_cashflow.tipe, akt_cashflow.jumlah FROM akt_cashflow LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_cashflow.id_transaksi WHERE akt_cashflow.tipe != 0 ORDER BY akt_transaksi.tanggal DESC")->result();
	}

	public function cashflowByMonthYear($month, $year)
	{
		return $this->db->query("SELECT akt_cashflow.tipe, SUM(akt_cashflow.jumlah) as 'jumlah' FROM akt_cashflow LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_cashflow.id_transaksi WHERE YEAR(akt_transaksi.tanggal) = '$year' AND MONTH(akt_transaksi.tanggal) = '$month' AND akt_cashflow.tipe != 0 GROUP BY akt_cashflow.tipe")->result();
	}


	// ++++++++++++++++++++++++++ Manajemen Cashflow
	// get casflow by id:
	public function getCashflowByIdTransaksi($id)
	{
		$this->db->where("id_transaksi", $id);
		return $this->db->get("akt_cashflow")->row();
	}
}