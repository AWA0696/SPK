<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Model
{
	// simpan transaksi
	public function simpanTransaksi($tanggal, $transaksi)
	{
		$this->db->insert('akt_transaksi', array('tanggal' => $tanggal, 'transaksi' => $transaksi));

		$insert_id = $this->db->insert_id();
		return  $insert_id;
	}

	// simpan jurnal umum
	// public function simpanJurnalUmum($id_transaksi, $debet_flag, $debet, $kredit_flag, $kredit)
	// {
	// 	$data = array(
	// 		'id_transaksi' => $id_transaksi,
	// 		'debet_flag' => $debet_flag,
	// 		'debet' => $debet,
	// 		'kredit_flag' => $kredit_flag,
	// 		'kredit' => $kredit
	// 	);

	// 	return $this->db->insert('akt_jurnal_umum', $data);
	// }

	// simpan jurnal umum:
	public function simpanJurnalUmum($id_transaksi)
	{
		$this->db->insert('akt_jurnal_umum', array('id_transaksi' => $id_transaksi));
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

	// simpan masing-masing akun debet. 
	public function simpanAkunDebet($id_jurnal_umum, $tipe, $id_sub_akun, $id_akun, $jumlah)
	{
		$data = array('id_jurnal_umum' => $id_jurnal_umum, 'tipe' => $tipe, 'id_sub_akun' => $id_sub_akun, 'id_akun' => $id_akun, 'jumlah' => $jumlah);
		return $this->db->insert('akt_jurnal_debet', $data);
	}

	// simpan masing-masing akun kredit. 
	public function simpanAkunKredit($id_jurnal_umum, $tipe, $id_sub_akun, $id_akun, $jumlah)
	{
		$data = array('id_jurnal_umum' => $id_jurnal_umum, 'tipe' => $tipe, 'id_sub_akun' => $id_sub_akun, 'id_akun' => $id_akun, 'jumlah' => $jumlah);
		return $this->db->insert('akt_jurnal_kredit', $data);
	}


	// simpan cashflow
	public function simpanCashflow($id_transaksi, $tipe, $jumlah, $posisi)
	{
		return $this->db->insert('akt_cashflow', array('id_transaksi' => $id_transaksi, 'tipe' => $tipe, 'jumlah' => $jumlah, 'posisi' => $posisi));
	}


	// +++++++++++++++++ Manajemen transaksi

	// dapatkan semua transaksi:
	public function getTransaksi()
	{
		$this->db->order_by("tanggal", "desc");
		return $this->db->get("akt_transaksi")->result();
	}

	public function getTransaksiByOffset($offset)
	{
		$this->db->order_by("tanggal", "desc");
		$this->db->limit(20, $offset);
		return $this->db->get("akt_transaksi")->result();
	}

	public function getTransaksiById($id)
	{
		$this->db->where("id", $id);
		return $this->db->get("akt_transaksi")->row();
	}

	// dapatkan total transaksi untuk keperluan pagination
	public function getNumTransaksi()
	{
		return $this->db->get("akt_transaksi")->num_rows();
	}


	// +++++++++++++++++ Operasi delete

	// get id jurnal umum
	public function getIdJurnalUmum($id_transaksi)
	{
		$this->db->where("id_transaksi", $id_transaksi);
		return $this->db->get("akt_jurnal_umum")->row()->id;
	}

	public function deleteCashflow($id_transaksi)
	{
		$this->db->where("id_transaksi", $id_transaksi);
		return $this->db->delete("akt_cashflow");
	}

	public function deleteJurnalDebet($id_jurnal_umum)
	{
		$this->db->where("id_jurnal_umum", $id_jurnal_umum);
		return $this->db->delete("akt_jurnal_debet");
	}

	public function deleteJurnalKredit($id_jurnal_umum)
	{
		$this->db->where("id_jurnal_umum", $id_jurnal_umum);
		return $this->db->delete("akt_jurnal_kredit");
	}

	public function deleteJurnalUmum($id_jurnal_umum)
	{
		$this->db->where("id", $id_jurnal_umum);
		return $this->db->delete("akt_jurnal_umum");
	}

	public function deleteTransaksi($id_transaksi)
	{
		$this->db->where("id", $id_transaksi);
		return $this->db->delete("akt_transaksi");
	}

	// dapatkan semua transaksi dari kas besar, kas kecil, kas operasional
	public function get_all_transaksi_kas()
	{
		return	$this->db->query("
  select 
        a.tanggal,
		a.jumlah,
		a.kredit,
        a.keterangan,		
		buktiansuran,
  		bukticicilan,
		buktipengeluarankasir,
    	idkasirkasbesar,		
		nama_pelanggan,
		bankasal,
		banktujuan,
		namaperumahan,
		a.jenis_pembayaran,
        	a.status	 

from ( select 
		b.bukti_pembayaran as buktipengeluarankasir,
        a.tanggal,
		a.jumlah,
		a.kredit,
        a.keterangan,		
		buktiansuran,
  		bukticicilan,	a.status,
    	idkasirkasbesar,		
		nama_pelanggan,
		bankasal,
		banktujuan,
		namaperumahan,
		a.jenis_pembayaran	 

 from (select 
b.bukti_pembayaran as buktiansuran,
 		bukticicilan,
		a.tanggal,
		a.jumlah,
		a.kredit,
     	a.keterangan,		
    	a.id as idkasirkasbesar,		
		nama_pelanggan,
		bankasal,	a.status,
		banktujuan,
		namaperumahan,
		a.jenis_pembayaran,
		a.id_table_lain 

from  ( select 
  b.bukti_pembayaran as bukticicilan,
		a.tanggal,
		a.jumlah,
		a.kredit,
       	a.keterangan,		
    	a.id,		
		nama_pelanggan,
		bankasal,	
		a.status,
		banktujuan,
		a.id_perumahan,
		namaperumahan,
		a.jenis_pembayaran,
		a.id_table_lain 
   from ( select 
		a.tanggal,
		a.jumlah,
		a.kredit,
       	a.keterangan,		
    	a.id,		
		nama_pelanggan,
		bankasal,	a.status,
		b.name as banktujuan,
		a.id_perumahan,
		namaperumahan,
		a.jenis_pembayaran,
		a.bank_asal_transfer,
		a.bank_tujuan_transfer,
		a.id_akad,
		a.id_table_lain
			
		from ( select 
		a.tanggal,
		a.jumlah,
		a.keterangan,
		a.id,		
		a.kredit,		
		nama_pelanggan,	a.status,
		b.name as bankasal,
		a.id_perumahan,
		namaperumahan,
		a.jenis_pembayaran,
		a.bank_asal_transfer,
		a.bank_tujuan_transfer,
		a.id_akad,
		a.id_table_lain
		
		from (select 
		a.tanggal,
		a.jumlah,a.id,
		a.keterangan,		
		a.kredit,	a.status,		
		nama_pelanggan,
		a.id_perumahan,
		b.nama as namaperumahan,
		a.jenis_pembayaran,
		a.bank_asal_transfer,
		a.bank_tujuan_transfer,
		a.id_akad,
		a.id_table_lain
		
		from (select 
		a.tanggal,
		a.jumlah,a.id,
		a.keterangan,		
		a.kredit,	
		a.status,	
		b.nama_pelanggan,
		b.id_perumahan,
		a.jenis_pembayaran,
		a.bank_asal_transfer,
		a.bank_tujuan_transfer,
		a.id_akad,
		a.id_table_lain
		from kasir_kas_besar a , akad b where a.id_akad=b.id and a.status=0 ) a
		LEFT JOIN perumahan b on a.id_perumahan=b.id ) a
		left join bank b on a.bank_asal_transfer = b.code ) a
		left join bank b on a.bank_tujuan_transfer = b.code  order by  id DESC ) a
        left join cicilan_akad b on a.id_table_lain=b.id ) a left join ansuran_rumah b on a.id_table_lain=b.id ) a  left join kasir_pengeluaran b on a.id_table_lain=b.id ) a

UNION
select 
tanggal, 
jumlah,
kredit,
keterangan,
null,
null,
bukti_pembayaran, 
idadministrator,   
null,
null,
null,
null,
null,
status

  from (SELECT id as idadministrator, 
  tanggal, jumlah,  
keterangan, 
kredit,
 bukti_pembayaran,
 id_table_lain,
 status 
 FROM `administrator_pengeluaran` where tipe_pengeluaran='1' and status=0)b
 

UNION
select 
tanggal, 
null,
kredit,
keterangan,
null,
null,
bukti_pembayaran, 
idoperan,   
null,
null,
null,
null,
null,
status

  from (SELECT id as idoperan, 
  tanggal,  
keterangan, 
kredit,
 bukti_pembayaran,
 status 
 FROM `administrator_operasional` where  kredit!=0 and status=0)b
 ")->result();
	}

	public function get_all_transaksi_kas_byid($id)
	{
		return $this->db->query("select 
a.tanggal,
a.jumlah,
a.kredit,
a.keterangan,		
buktiansuran,
  bukticicilan,
buktipengeluarankasir,
idkasirkasbesar,		
nama_pelanggan,
bankasal,
banktujuan,
namaperumahan,
a.jenis_pembayaran,
	a.status	 

from ( select 
b.bukti_pembayaran as buktipengeluarankasir,
a.tanggal,
a.jumlah,
a.kredit,
a.keterangan,		
buktiansuran,
  bukticicilan,	a.status,
idkasirkasbesar,		
nama_pelanggan,
bankasal,
banktujuan,
namaperumahan,
a.jenis_pembayaran	 

from (select 
b.bukti_pembayaran as buktiansuran,
 bukticicilan,
a.tanggal,
a.jumlah,
a.kredit,
 a.keterangan,		
a.id as idkasirkasbesar,		
nama_pelanggan,
bankasal,	a.status,
banktujuan,
namaperumahan,
a.jenis_pembayaran,
a.id_table_lain 

from  ( select 
b.bukti_pembayaran as bukticicilan,
a.tanggal,
a.jumlah,
a.kredit,
   a.keterangan,		
a.id,		
nama_pelanggan,
bankasal,	
a.status,
banktujuan,
a.id_perumahan,
namaperumahan,
a.jenis_pembayaran,
a.id_table_lain 
from ( select 
a.tanggal,
a.jumlah,
a.kredit,
   a.keterangan,		
a.id,		
nama_pelanggan,
bankasal,	a.status,
b.name as banktujuan,
a.id_perumahan,
namaperumahan,
a.jenis_pembayaran,
a.bank_asal_transfer,
a.bank_tujuan_transfer,
a.id_akad,
a.id_table_lain
	
from ( select 
a.tanggal,
a.jumlah,
a.keterangan,
a.id,		
a.kredit,		
nama_pelanggan,	a.status,
b.name as bankasal,
a.id_perumahan,
namaperumahan,
a.jenis_pembayaran,
a.bank_asal_transfer,
a.bank_tujuan_transfer,
a.id_akad,
a.id_table_lain

from (select 
a.tanggal,
a.jumlah,a.id,
a.keterangan,		
a.kredit,	a.status,		
nama_pelanggan,
a.id_perumahan,
b.nama as namaperumahan,
a.jenis_pembayaran,
a.bank_asal_transfer,
a.bank_tujuan_transfer,
a.id_akad,
a.id_table_lain

from (select 
a.tanggal,
a.jumlah,a.id,
a.keterangan,		
a.kredit,	
a.status,	
b.nama_pelanggan,
b.id_perumahan,
a.jenis_pembayaran,
a.bank_asal_transfer,
a.bank_tujuan_transfer,
a.id_akad,
a.id_table_lain
from kasir_kas_besar a , akad b where a.id_akad=b.id and a.status=0 ) a
LEFT JOIN perumahan b on a.id_perumahan=b.id ) a
left join bank b on a.bank_asal_transfer = b.code ) a
left join bank b on a.bank_tujuan_transfer = b.code  order by  id DESC ) a
left join cicilan_akad b on a.id_table_lain=b.id ) a left join ansuran_rumah b on a.id_table_lain=b.id ) a  left join kasir_pengeluaran b on a.id_table_lain=b.id ) a where idkasirkasbesar = '$id'")->row();
	}
}
