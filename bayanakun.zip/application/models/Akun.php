<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akun extends CI_Model
{
	public function getSubAkun()
	{
		$this->db->select("akt_sub_akun.id, akt_sub_akun.id_akun, akt_sub_akun.nama, akt_sub_akun.jenis, akt_akun.nama as 'nama_akun'");
		$this->db->from("akt_sub_akun");
		$this->db->join("akt_akun", "akt_akun.id = akt_sub_akun.id_akun");
		return $this->db->get()->result();
	}

	public function getAkun()
	{
		// $this->db->select('akt_akun.id, akt_akun.nama, akt_sub_akun.jenis');
		// $this->db->from("akt_akun");
		// $this->db->join("akt_sub_akun", "akt_sub_akun.id_akun = akt_akun.id");
		// return $this->db->get()->result();
		$this->db->order_by("id", "ASC");
		return $this->db->get('akt_akun')->result();
	}

	public function getIsAkun()
	{
		$this->db->select("akt_is_sub_akun.id, akt_is_sub_akun.id_akun, akt_is_sub_akun.nama, akt_is_sub_akun.jenis, akt_is_akun.nama as 'nama_akun'");
		$this->db->from("akt_is_sub_akun");
		$this->db->join("akt_is_akun", "akt_is_akun.id = akt_is_sub_akun.id_akun");
		return $this->db->get()->result();
	}

	// dapatkan id_akun berdasarkan id_sub_akun
	public function getAkunBySub($id_sub_akun)
	{
		$this->db->where('id', $id_sub_akun);
		return $this->db->get("akt_sub_akun")->row()->id_akun;
	}

	public function getIsAkunBySub($id_sub_akun)
	{
		$this->db->where('id', $id_sub_akun);
		return $this->db->get("akt_is_sub_akun")->row()->id_akun;
	}

	// histori transaksi akun:
	public function history_debet($id_sub_akun, $tipe) // tipe: 1: balance sheet, 2: income statement
	{
		$this->db->where("tipe", $tipe);
		$this->db->where("id_sub_akun", $id_sub_akun);
		$this->db->select("akt_transaksi.tanggal, akt_transaksi.transaksi, akt_jurnal_debet.jumlah AS 'debet'");
		$this->db->from("akt_transaksi");
		$this->db->join("akt_jurnal_umum", "akt_jurnal_umum.id_transaksi = akt_transaksi.id");
		$this->db->join("akt_jurnal_debet", "akt_jurnal_debet.id_jurnal_umum = akt_jurnal_umum.id");
		return $this->db->get()->result();
	}

	public function history_kredit($id_sub_akun, $tipe) // tipe: 1: balance sheet, 2: income statement
	{
		$this->db->where("tipe", $tipe);
		$this->db->where("id_sub_akun", $id_sub_akun);
		$this->db->select("akt_transaksi.tanggal, akt_transaksi.transaksi, akt_jurnal_kredit.jumlah AS 'kredit'");
		$this->db->from("akt_transaksi");
		$this->db->join("akt_jurnal_umum", "akt_jurnal_umum.id_transaksi = akt_transaksi.id");
		$this->db->join("akt_jurnal_kredit", "akt_jurnal_kredit.id_jurnal_umum = akt_jurnal_umum.id");
		return $this->db->get()->result();
	}

	public function getNamaAkun($id_sub_akun)
	{
		$this->db->where("id", $id_sub_akun);
		return $this->db->get("akt_sub_akun")->row()->nama;
	}

	public function getIsNamaAkun($id_sub_akun)
	{
		$this->db->where("id", $id_sub_akun);
		return $this->db->get("akt_is_sub_akun")->row()->nama;
	}


	// inisialisasi akun:
	public function init_akun_debet($tipe, $id_sub_akun, $jumlah)
	{
		$data = array("tipe" => $tipe, "id_sub_akun" => $id_sub_akun, "jumlah" => $jumlah);
		return $this->db->replace("akt_init_debet", $data);
	}

	public function init_akun_kredit($tipe, $id_sub_akun, $jumlah)
	{
		$data = array("tipe" => $tipe, "id_sub_akun" => $id_sub_akun, "jumlah" => $jumlah);
		return $this->db->replace("akt_init_kredit", $data);
	}


}