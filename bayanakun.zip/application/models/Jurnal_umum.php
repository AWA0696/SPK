<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jurnal_umum extends CI_Model
{
	// public function getJurnalUmum()
	// {
	// 	$this->db->select("akt_transaksi.tanggal, akt_jurnal_umum.debet_flag, akt_jurnal_umum.debet, akt_jurnal_umum.kredit_flag, akt_jurnal_umum.kredit, akt_transaksi.jumlah");
	// 	$this->db->from("akt_jurnal_umum");
	// 	$this->db->join("akt_transaksi", "akt_transaksi.id = akt_jurnal_umum.id_transaksi");

	// 	return $this->db->get()->result();
	// }

	public function getJurnalUmum()
	{
		return $this->db->query("SELECT akt_jurnal_umum.id AS 'id_jurnal_umum', akt_transaksi.tanggal FROM akt_jurnal_umum LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_jurnal_umum.id_transaksi")->result();
	}

	public function getJurnalUmumByOffset($offset)
	{
		// return $this->db->query("SELECT akt_jurnal_umum.id AS 'id_jurnal_umum', akt_transaksi.tanggal FROM akt_jurnal_umum LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_jurnal_umum.id_transaksi LIMIT 20 OFFSET ".$offset)->result();
		return $this->db->query("SELECT akt_jurnal_umum.id AS 'id_jurnal_umum', akt_transaksi.tanggal FROM akt_jurnal_umum LEFT JOIN akt_transaksi ON akt_transaksi.id = akt_jurnal_umum.id_transaksi ORDER BY akt_transaksi.tanggal DESC LIMIT 20 OFFSET ".$offset)->result();
	}

	// dapatkan total jurnal umum: 
	public function getNumJurnalUmum()
	{
		return $this->db->get('akt_jurnal_umum')->num_rows();
	}

	public function getAkunDebet($id_jurnal_umum)
	{
		$this->db->select("akt_jurnal_debet.tipe, akt_jurnal_debet.id_sub_akun, akt_jurnal_debet.jumlah");
		$this->db->from("akt_jurnal_debet");
		$this->db->where("akt_jurnal_debet.id_jurnal_umum", $id_jurnal_umum);
		return $this->db->get()->result();
	}

	public function getAkunKredit($id_jurnal_umum)
	{
		$this->db->select("akt_jurnal_kredit.tipe, akt_jurnal_kredit.id_sub_akun, akt_jurnal_kredit.jumlah");
		$this->db->from("akt_jurnal_kredit");
		$this->db->where("akt_jurnal_kredit.id_jurnal_umum", $id_jurnal_umum);
		return $this->db->get()->result();
	}


}