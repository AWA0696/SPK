<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Init extends CI_Model
{
	// Dapatkan ini balance sheet
	public function getInitBsDebet()
	{
		$this->db->where("tipe", 1); // 1 = balance sheet
		return $this->db->get("akt_init_debet")->result();
	}

	public function getInitBsKredit()
	{
		$this->db->where("tipe", 1); // 1 = balance sheet
		return $this->db->get("akt_init_kredit")->result();
	}

	// dapatkan ini income statement:
	public function getInitIsDebet()
	{
		$this->db->where("tipe", 2); 
		return $this->db->get("akt_init_debet")->result();
	}

	public function getInitIsKredit()
	{
		$this->db->where("tipe", 2); 
		return $this->db->get("akt_init_kredit")->result();
	}


	// hapus data init
	public function del_init_debet($tipe, $id_sub_akun)
	{
		$this->db->where("tipe", $tipe);
		$this->db->where("id_sub_akun", $id_sub_akun);

		return $this->db->delete("akt_init_debet");
	}

	public function del_init_kredit($tipe, $id_sub_akun)
	{
		$this->db->where("tipe", $tipe);
		$this->db->where("id_sub_akun", $id_sub_akun);

		return $this->db->delete("akt_init_kredit");
	}
}