<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Balance_sheet extends CI_Model
{
	public function getBalanceSheet()
	{
		return $this->db->query("
			SELECT id_akun, nama_akun, id_sub_akun, nama_sub_akun, SUM(bs.jumlah) AS 'sum_sub_akun', jenis FROM
			(
			    SELECT akt_transaksi.jumlah, akt_akun.id AS 'id_akun', akt_akun.nama AS 'nama_akun' , akt_jurnal_umum.debet as 'id_sub_akun', akt_sub_akun.nama AS 'nama_sub_akun', akt_sub_akun.jenis FROM akt_transaksi LEFT JOIN akt_jurnal_umum ON akt_transaksi.id = akt_jurnal_umum.id_transaksi LEFT JOIN akt_sub_akun ON akt_sub_akun.id = akt_jurnal_umum.debet LEFT JOIN akt_akun ON akt_akun.id = akt_sub_akun.id_akun WHERE akt_jurnal_umum.debet_flag = 1

			UNION ALL

			SELECT akt_transaksi.jumlah, akt_akun.id AS 'id_akun', akt_akun.nama AS 'nama_akun', akt_jurnal_umum.kredit as 'id_sub_akun', akt_sub_akun.nama AS 'nama_sub_akun', akt_sub_akun.jenis FROM akt_transaksi LEFT JOIN akt_jurnal_umum ON akt_transaksi.id = akt_jurnal_umum.id_transaksi LEFT JOIN akt_sub_akun ON akt_sub_akun.id = akt_jurnal_umum.kredit LEFT JOIN akt_akun ON akt_akun.id = akt_sub_akun.id_akun WHERE akt_jurnal_umum.kredit_flag = 1

			    ) AS bs
			GROUP BY bs.id_sub_akun
		")->result();
		
	}

	// dapatkan semua balance sheet debet.
	public function getDebet()
	{
		$this->db->where("tipe", 1); // tipe balance sheet. 
		return $this->db->get("akt_jurnal_debet")->result();
	}

	// balance sheet kredit:
	public function getKredit()
	{
		$this->db->where("tipe", 1); // tipe balance sheet. 
		return $this->db->get("akt_jurnal_kredit")->result();
	}

	// sum jumlah pada setiap akun:
	public function getSumDebet()
	{
		return $this->db->query("SELECT tipe, id_sub_akun, SUM(jumlah) AS 'jumlah' FROM akt_jurnal_debet WHERE tipe = 1 GROUP BY id_sub_akun")->result();
	}

	public function getSumKredit()
	{
		return $this->db->query("SELECT akt_jurnal_kredit.tipe, akt_jurnal_kredit.id_sub_akun, SUM(akt_jurnal_kredit.jumlah) AS 'jumlah' FROM akt_jurnal_kredit WHERE tipe = 1 GROUP BY akt_jurnal_kredit.id_sub_akun")->result();
	}

}