<div class="container-fluid">
	<div class="card shadow">
	<div class="card-header bg-primary">
		<h6 class="m-0 font-weight-bold text-gray-100">Jurnal Umum</h6>
	</div>
		<div class="card-body">
		
		<div class="card shadow">
		<div class="card-body">
		<div class="row">
			<div class="col-lg-2 border-right bg-primary m-0 font-weight-bold text-gray-100">Tanggal</div>
			<div class="col lg-6 text-center border-right bg-primary m-0 font-weight-bold text-gray-100">General Journal</div>
			<div class="col-lg-2 border-right bg-primary m-0 font-weight-bold text-gray-100">Debet</div>
			<div class="col-lg-2 bg-primary m-0 font-weight-bold text-gray-100">Kredit</div>
		</div>

		<?php
		$i=0;
		foreach($jurnal_umum as $ju)
		{
			$i++;			

			// $this->load->model("Jurnal_umum");
			$akun_debet = $this->Jurnal_umum->getAkunDebet($ju->id_jurnal_umum);
			$data_akun_debet = array();
			foreach($akun_debet as $a_debet)
			{
				$nama_akun_debet = '';
				if($a_debet->tipe == 1) // akun biasa
				{
					foreach($akun as $ak)
					{
						if($ak->id == $a_debet->id_sub_akun)
						{
							$nama_akun_debet = $ak->nama;
							break;
						}
					}
					
				}
				else // akun income statement
				{
					foreach($akun_is as $ak)
					{
						if($ak->id == $a_debet->id_sub_akun)
						{
							$nama_akun_debet = $ak->nama;
							break;
						}
					}
				}
				array_push($data_akun_debet, ['nama' => $nama_akun_debet, 'jumlah' => $a_debet->jumlah]);
			}
			
			// akun kredit:
			$akun_kredit = $this->Jurnal_umum->getAkunKredit($ju->id_jurnal_umum);
			$data_akun_kredit = array();
			foreach($akun_kredit as $a_kredit)
			{
				$nama_akun_kredit = '';
				if($a_kredit->tipe == 1) // akun biasa
				{
					foreach($akun as $ak)
					{
						if($ak->id == $a_kredit->id_sub_akun)
						{
							$nama_akun_kredit = $ak->nama;
							break;
						}
					}
					
				}
				else // akun income statement
				{
					foreach($akun_is as $ak)
					{
						if($ak->id == $a_kredit->id_sub_akun)
						{
							$nama_akun_kredit = $ak->nama;
							break;
						}
					}
				}
				array_push($data_akun_kredit, ['nama' => $nama_akun_kredit, 'jumlah' => $a_kredit->jumlah]);
			}

			// print_r($data_akun_debet);
			// echo "<br>";
			// print_r($data_akun_kredit);

			echo "<div class='row'>";

			echo "<div class='col-lg-2'>".$ju->tanggal."</div>";

			echo "<div class='col-lg-3'>";
				
				foreach($data_akun_debet as $dad)
				{
					echo "<div class='row'>";      
					echo "<div class='col'>".$dad['nama']."</div>";
					echo "</div>"; // row
				}							
			echo "</div>"; // col-lg-4
			echo "<div class='col-lg-3'>";
				foreach($data_akun_debet as $dad)
				{
					echo "<div class='row'>&nbsp;</div>";
				}
				foreach($data_akun_kredit as $dak)
				{
					echo "<div class='row'>";
					echo "<div class='col'>".$dak['nama']."</div>";
					echo "</div>";
				}
			echo "</div>"; // col-lg-3
			echo "<div class='col-lg-2'>";
				foreach($data_akun_debet as $dad)
				{
					echo "<div class='row'>";      
					echo "<div class='col'>".$this->pitih->formatrupiah($dad['jumlah'])."</div>";
					echo "</div>"; // row
				}
			echo "</div>"; // col-lg-2
			echo "<div class='col-lg-2'>";
				foreach($data_akun_debet as $dad)
				{
					echo "<div class='row'>&nbsp;</div>";
				}
				foreach($data_akun_kredit as $dak)
				{
					echo "<div class='row'>";
					echo "<div class='col'>".$this->pitih->formatrupiah($dak['jumlah'])."</div>";
					echo "</div>";
				}
			echo "</div>";

			echo "</div>";
		}		

		?>
	</div> <!-- card-body -->
	</div> <!-- card -->
	<!-- pagination -->
	<div class="text-center mt-1">Halaman: <?= $page ?></div>
	</div>
	</div>
</div>