<div class="container-fluid">
	<a onclick="history.back(-1)" class="btn btn-primary btn-icon-split mb-3">
        <span class="icon text-white-50">
            <i class="fas fa-caret-square-left"></i>
        </span>
        <span class="text">Kembali</span>
    </a>

	<div class="card shadow">
		<div class="card-header bg-primary">
			<h6 class="m-0 font-weight-bold text-gray-100">History Akun "<?= $nama_sub_akun ?>"</h6>
		</div>
		<div class="card-body">
			<div class="row">
				<div class="col-sm-3 bg-primary m-0 font-weight-bold text-gray-100 border-right">Tanggal</div>
				<div class="col-sm-5 bg-primary m-0 font-weight-bold text-gray-100 border-right">Transaksi</div>
				<div class="col-sm-2 bg-primary m-0 font-weight-bold text-gray-100 border-right">Debet</div>
				<div class="col-sm-2 bg-primary m-0 font-weight-bold text-gray-100">Kredit</div>
			</div>
			<?php
			foreach($history as $his)
			{
				if(isset($his->debet))
				{
					$a_debet = $this->pitih->formatrupiah($his->debet);
				}
				else
				{
					$a_debet = "";
				}

				if(isset($his->kredit))
				{
					$a_kredit = $this->pitih->formatrupiah($his->kredit);
				}
				else
				{
					$a_kredit = "";
				}

				echo "<div class='row'>";
				echo "<div class='col-sm-3'>".$his->tanggal."</div>";
				echo "<div class='col-sm-5'>".$his->transaksi."</div>";
				echo "<div class='col-sm-2'>".$a_debet."</div>";
				echo "<div class='col-sm-2'>".$a_kredit."</div>";
				echo "</div>";
			}

			?>
		</div>
	</div>
</div>