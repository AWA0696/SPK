<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="card-header bg-primary">
                    <h6 class="m-0 font-weight-bold text-gray-100">Semua Transaksi</h6>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <thead>
                            <tr class="bg-primary m-0 font-weight-bold text-gray-100">
                                <th class="border-right">No</th>
                                <th class="border-right">Tanggal</th>
                                <th class="border-right">Transaksi</th>
                                <th class="border-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
                            foreach ($transaksi as $d) {
                                $i++;
                            ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= date('d-m-Y', strtotime($d->tanggal)) ?></td>
                                    <td><?php if ($d->keterangan == "Cicilan Akad") {
                                            $ke = 'Angsuran DP';
                                        } else if ($d->keterangan == "KPR") {
                                            $ke = 'KPR';
                                        } else if ($d->keterangan == "Dp Booking Fee") {
                                            $ke = 'Booking Fee';
                                        } else {
                                            $ke = $d->keterangan;
                                        }

                                        if ($d->keterangan == "Cicilan Akad") {
                                            $ket = $d->nama_pelanggan . ' membayar ' . $ke . ' Perumahan ' . $d->namaperumahan . ' Sebesar ' . $this->pitih->formatrupiah($d->jumlah);
                                        } else if ($d->keterangan == "KPR") {
                                            $ket = ' Pencairan ' . $ke . ' ' . $d->nama_pelanggan . ' Perumahan ' . $d->namaperumahan . ' dari ' . $d->banktujuan . ' Sebesar ' . $this->pitih->formatrupiah($d->jumlah);
                                        } else if ($d->keterangan == "Dp Booking Fee") {
                                            $ket = $d->nama_pelanggan . ' membayar ' . $ke . ' Perumahan ' . $d->namaperumahan . ' Sebesar ' . $this->pitih->formatrupiah($d->jumlah);
                                        } else {
                                            $ket = $d->keterangan;
                                        }

                                        echo $ket; ?></td>
                                    <td>
                                        <a href="<?= site_url('Akuntan/input/' . $d->idkasirkasbesar) ?>" class="btn btn-primary">Input</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>