<link href="<?= base_url('assets/css/') ?>select2.min.css" rel="stylesheet" />
