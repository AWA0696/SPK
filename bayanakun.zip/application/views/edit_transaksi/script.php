<script src="<?= base_url('assets/js/') ?>select2.min.js"></script>
<script>
	$(document).ready(function() {
	    $('#akun_debet_0').select2();
	    $('#akun_kredit_0').select2();
	    num_akun_debet = 0;
	    num_akun_kredit = 0;
	    renderAngkaRupiah();
	    total_jumlah_kredit = 0;
	    total_jumlah_debet = 0;
	});

	// penambahan input akun debet
	$("#tambah-debet").click(function(){
		num_akun_debet++;
		id_akun_debet = 'akun_debet_'+num_akun_debet;
		rowd_id = 'rowd_'+num_akun_debet;
		text = "<div class='row mt-1' id='"+rowd_id+"'><div class='col-sm-2'><button type='button' onclick=hapus_akun('"+rowd_id+"') id='hapus-debet' class='btn btn-danger btn-icon-split btn-sm mb-1'><span class='icon text-white-50'><i class='fas fa-minus-square'></i></span><span class='text'>HAPUS</span></button></div>"
		text += "<div class='col-sm-6 mt-1'><select name='akun_debet[]' id='"+id_akun_debet+"' class='form-control akun_debet'>";
		text += list_akun;
		text += list_akun_is;
		text = text + "</select></div><div class='col-sm-4'><input name='angka_debet[]' type='text' class='form-control angka_rupiah' placeholder='Jumlah Rp. '></div></div>";
		$("#akun_debet_container").append(text);	
		
		console.log(id_akun_debet);
		$('#'+id_akun_debet).select2();
		renderAngkaRupiah();
	});

	// penambahan akun kredit:
	$("#tambah-kredit").click(function(){
		num_akun_kredit++;
		id_akun_kredit = 'akun_kredit_'+num_akun_kredit;
		rowk_id = 'rowk_'+num_akun_kredit;
		text = "<div class='row mt-1' id='"+rowk_id+"'><div class='col-sm-2'><button type='button' onclick=hapus_akun('"+rowk_id+"') id='hapus-kredit' class='btn btn-danger btn-icon-split btn-sm mb-1'><span class='icon text-white-50'><i class='fas fa-minus-square'></i></span><span class='text'>HAPUS</span></button></div>"
		text += "<div class='col-sm-6 mt-1'><select name='akun_kredit[]' id='"+id_akun_kredit+"' class='form-control akun_kredit'>";
		text += list_akun;
		text += list_akun_is;
		text = text + "</select></div><div class='col-sm-4'><input name='angka_kredit[]' type='text' class='form-control angka_rupiah' placeholder='Jumlah Rp. '></div></div>";
		$("#akun_kredit_container").append(text);	
		
		console.log(id_akun_kredit);
		$('#'+id_akun_kredit).select2();
		renderAngkaRupiah();
	});

	function hapus_akun(id){
		$('#'+id).remove();
		console.log("id hapus= " + id);
	}


	var rupiah = document.getElementById('jumlah');
	rupiah.addEventListener('keyup', function(e){
		// tambahkan 'Rp.' pada saat form di ketik
		// gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
		rupiah.value = formatRupiah(this.value, 'Rp. ');
	});


	function renderAngkaRupiah(){
		var rupiah2 = document.getElementsByClassName('angka_rupiah');
	
		for(i=0;i<rupiah2.length;i++)
		{
			rupiah2[i].addEventListener('keyup', function(e){
				// tambahkan 'Rp.' pada saat form di ketik
				// gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
				this.value = formatRupiah(this.value, 'Rp. ');
			});

			// console.log(rupiah2[i]);
		}
	}

	function formatRupiah(angka, prefix){
		var number_string = angka.replace(/[^,\d]/g, '').toString(),
		split   		= number_string.split(','),
		sisa     		= split[0].length % 3,
		rupiah     		= split[0].substr(0, sisa),
		ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

		// tambahkan titik jika yang di input sudah menjadi angka ribuan
		if(ribuan){
			separator = sisa ? '.' : '';
			rupiah += separator + ribuan.join('.');
		}

		rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
		return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
	}
	


</script>