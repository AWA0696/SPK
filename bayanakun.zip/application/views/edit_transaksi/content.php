<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<div class="card shadow">
				<div class="card-header bg-primary">
					<h6 class="m-0 font-weight-bold text-gray-100">Input Transaksi</h6>
				</div>
				<div class="card-body">
					<form method="post" action="<?= base_url('Akuntan/input') ?>" class="form-horizontal">	
						  <div class="row mb-3">
						  	  <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
							  <div class="col-sm-10">
							  	<input type="date" name="tanggal" id="tanggal" class="form-control"> 
							  </div>						  		
						  </div>
						  <div class="row mb-3">
						  		<label for="transaksi" class="col-sm-2 col-form-label">Transaksi</label>
						  		<div class="col-sm-10">
						  			<textarea name="transaksi" id="transaksi" cols="30" rows="4" class="form-control"></textarea>
						  		</div>						  		
						  </div>
						  <!-- <div class="row mb-3">
						  		<label for="jumlah" class="col-sm-2 col-form-label">Jumlah</label>
						  		<div class="col-sm-10">
						  			<input type="text" name="jumlah" id="jumlah" class="form-control">
						  		</div>					  		
						  </div> -->	
						  

						  <div class="row mb-3">
						  		<!-- <label for="akun_debet" class="col-sm-2 col-form-label">Akun pada Debet</label> -->
						  		<div class="col-sm-12">
						  		<div class="card shadow">
						  			<div class="card-header">
						  				<h6 class="m-0 font-weight-bold text-gray-1000">Akun Pada Debet</h6>
						  			</div>
						  			<div class="card-body" id="akun_debet_container">
						  				<div class="row">
						  					<div class="col-sm-10 offset-2">
						  						<button type="button" id="tambah-debet" class="btn btn-primary btn-icon-split btn-sm mb-3">
					                                <span class="icon text-white-50">
					                                    <i class="fas fa-plus-square"></i>
					                                </span>
					                                <span class="text">TAMBAH AKUN</span>
					                            </button>
						  					</div>
						  				</div>

						  				<div class="row">
						  					<div class="col-sm-6 offset-2">
						  						<select name="akun_debet[]" id="akun_debet_0" class="form-control">
									  				<?php 
									  				foreach($akun as $ak)
									  				{
									  					$id = 'a'.$ak->id;
									  					echo "<option value='$id'>$ak->nama</option>";
									  				}

									  				foreach($akun_is as $ak)
									  				{
									  					$id = 'i'.$ak->id;
									  					echo "<option value='$id'>$ak->nama</option>";
									  				}

									  				?>
									  			</select>					  				  			
						  					</div>
						  					<div class="col-sm-4">
									  			<input name="angka_debet[]" type="text" class="form-control angka_rupiah jumlah_debet" placeholder="Jumlah Rp. ">
									  		</div>
						  				</div>
						  				
						  			</div> <!-- card body -->
						  		</div>	<!-- card -->
						  		</div>						  							  		
						  </div>
						  
						  <div class="row mb-3">
						  	<div class="col-sm-12">
						  	<div class="card shadow ">
						  		<div class="card-header">
						  			<h6 class="m-0 font-weight-bold text-gray-1000">Akun Pada Kredit</h6>
						  		</div>
						  		<div class="card-body" id="akun_kredit_container">

						  		<div class="row">
						  			<div class="col-sm-10 offset-2">
						  				<button type="button" id="tambah-kredit" class="btn btn-primary btn-icon-split btn-sm mb-3">
			                                <span class="icon text-white-50">
			                                    <i class="fas fa-plus-square"></i>
			                                </span>
			                                <span class="text">TAMBAH AKUN</span>
			                            </button>
						  			</div>
						  		</div>	

						  		<div class="row">
						  			<div class="col-sm-6 offset-2">
						  				<select name="akun_kredit[]" id="akun_kredit_0" class="form-control">
							  				<?php 
							  				foreach($akun as $ak)
							  				{
							  					$id = 'a'.$ak->id;
							  					echo "<option value='$id'>$ak->nama</option>";
							  				}

							  				foreach($akun_is as $ak)
							  				{
							  					$id = 'i'.$ak->id;
							  					echo "<option value='$id'>$ak->nama</option>";
							  				}

							  				?>
							  			</select>
						  			</div>
						  			<div class="col-sm-4">
							  			<input name="angka_kredit[]" type="text" class="form-control angka_rupiah jumlah_kredit" placeholder="Jumlah Rp. ">
							  		</div>	
						  		</div>						  							  		

						  		</div>	
							</div>
							</div>						  		
						  </div>
						  
						  <div class="row mb-3">
						  		<label for="cashflow" class="col-sm-2 col-form-label">Cashflow</label>
						  		<div class="col-sm-5">
						  			
									  <input type="radio" name="cashflow" id="casflow0" checked="checked" value=0>
									  <label for="cashflow0">-</label><br>
									  <input type="radio" name="cashflow" id="casflow1" value=1>
									  <label for="cashflow1">OCF</label><br>
									  <input type="radio" name="cashflow" id="casflow2" value=2>
									  <label for="cashflow2">ICF</label><br>
									  <input type="radio" name="cashflow" id="casflow3" value=3>
									  <label for="cashflow3">FCF</label>
								  		  
						  		</div>  
						  		<div class="col-sm-5">
						  			<label for="angka_cashflow">Jumlah</label>
						  			<input type="text" name="angka_cashflow" id="angka_cashflow" class="form-control angka_rupiah" placeholder="Rp. ">
						  			<label for="posisi_cashflow" class="control-label">Posisi Cashflow</label>
						  			<select name="posisi_cashflow" id="posisi_cashflow" class="form-control">
						  				<!-- <option value="-" selected="true" disabled="disabled">--- Pilih Salah Satu ---</option> -->
						  				<option value="1">Positif</option>
						  				<option value="0">Negatif</option>
						  			</select>
						  		</div>
						  		
                            </div>

                            <div class="row mb-3">
                            	<div class="col-sm-2 offset-sm-2">
                            		<button type="submit" class="btn btn-primary btn-icon-split">
                            			<span class="icon text-white-50">
                            				<i class="fas fa-save"></i>
                            			</span>
                            			<span class="text">
                            				SIMPAN
                            			</span>
                            			
                            		</button>
                            	</div>                            	
                            </div>
					</form>
					
				</div>
			</div>
		</div>
		
	</div>
</div>

<?php 
// simpan daftar akun ke dalam array:

$list_akun = "";
echo "<script>";
foreach($akun as $ak)
{
	$id = 'a'.$ak->id;	
	$list_akun .= "<option value='$id'>".$ak->nama."</option>";	
}
echo "list_akun = \"".$list_akun."\"";
echo "</script>";

$list_akun_is = "";
echo "<script>";
foreach($akun_is as $ak)
{
	$id = 'i'.$ak->id;	
	$list_akun_is .= "<option value='$id'>".$ak->nama."</option>";	
}
echo "list_akun_is = \"".$list_akun_is."\"";
echo "</script>";

?>