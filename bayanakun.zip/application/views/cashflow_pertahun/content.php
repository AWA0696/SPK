<div class="container-fluid">
	<h1 class="h3 mb-4 text-gray-800">Laporan Cashflow Tahun: <?= $tahun ?></h1>
	<a href="<?= base_url('Akuntan/cashflow') ?>" class="btn btn-primary btn-icon-split">
	    <span class="icon text-white-50">        
	        <i class="fas fa-angle-double-left"></i>
	    </span>
	    <span class="text">KEMBALI</span>
	</a>

	<div class="card shadow mt-2">
		<div class="card-header bg-primary">
			<h6 class="m-0 font-weight-bold text-gray-100">Laporan Cashflow </h6>			
		</div>
		<div class="card-body">
			<?php
			$bulan = array(
	            '1' => 'Januari',
	            '2' => 'Februari',
	            '3' => 'Maret',
	            '4' => 'April',
	            '5' => 'Mei',
	            '6' => 'Juni',
	            '7' => 'Juli',
	            '8' => 'Agustus',
	            '9' => 'September',
	            '10' => 'Oktober',
	            '11' => 'November',
	            '12' => 'Desember'
	        );

        
        	$this->load->model("Cashflow");
        	echo "<div class='row'>";
        	echo "<div class='col-sm-6 bg-primary text-gray-100 border-right'>BULAN</div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100 border-right'>OCF</div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100 border-right'>ICF</div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100'>FCF</div>";
        	echo "</div>";	 

        	// total 
        	$data_ocf = array();
        	$data_icf = array();
        	$data_fcf = array();


        	foreach($bulan as $key => $bl)
        	{
        		$ocf = 0;
                $icf = 0;
                $fcf = 0;
                $cashflow = $this->Cashflow->cashflowByMonthYear($key, $tahun);
        		if(empty($cashflow))
        		{
        			$ocf = 0;
        			$icf = 0;
        			$fcf = 0;
        		}
        		else
        		{
        			if(!empty($cashflow[0])){$ocf=$cashflow[0]->jumlah;}else{$ocf = 0;}
                    if(!empty($cashflow[1])){$icf=$cashflow[1]->jumlah;}else{$icf = 0;}
                    if(!empty($cashflow[2])){$fcf=$cashflow[2]->jumlah;}else{$fcf = 0;}
           //                      $ocf = $cashflow[0]->jumlah;
        			// $icf = $cashflow[1]->jumlah;
        			// $fcf = $cashflow[2]->jumlah;
        		}

        		if($ocf >= 0){$d_ocf = $this->pitih->formatrupiah($ocf);}else{$d_ocf = "(".$this->pitih->formatrupiah(($ocf * -1)).")";}
        		if($icf >= 0){$d_icf = $this->pitih->formatrupiah($icf);}else{$d_icf = "(".$this->pitih->formatrupiah(($icf * -1)).")";}
        		if($fcf >= 0){$d_fcf = $this->pitih->formatrupiah($fcf);}else{$d_fcf = "(".$this->pitih->formatrupiah(($fcf * -1)).")";}

        		echo "<div class='row'>";
        		echo "<div class='col-sm-6'>".$bl."</div>";
        		echo "<div class='col-sm-2'>".$d_ocf."</div>";
        		echo "<div class='col-sm-2'>".$d_icf."</div>";
        		echo "<div class='col-sm-2'>".$d_fcf."</div>";
        		echo "</div>";

        		array_push($data_ocf, $ocf);
        		array_push($data_icf, $icf);
        		array_push($data_fcf, $fcf);
        	}  

        	if(array_sum($data_ocf) >= 0){$sum_ocf = $this->pitih->formatrupiah(array_sum($data_ocf));}else{$sum_ocf = "(".$this->pitih->formatrupiah((array_sum($data_ocf)*-1)).")";}

        	if(array_sum($data_icf) >= 0){$sum_icf = $this->pitih->formatrupiah(array_sum($data_icf));}else{$sum_icf = "(".$this->pitih->formatrupiah((array_sum($data_icf)*-1)).")";}

        	if(array_sum($data_fcf) >= 0){$sum_fcf = $this->pitih->formatrupiah(array_sum($data_fcf));}else{$sum_fcf = "(".$this->pitih->formatrupiah((array_sum($data_fcf)*-1)).")";}

        	echo "<div class='row'>";
        	echo "<div class='col-sm-6 bg-primary text-gray-100 font-weight-bold border-right'>Total </div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100 font-weight-bold border-right'>".$sum_ocf."</div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100 font-weight-bold border-right'>".$sum_icf."</div>";
        	echo "<div class='col-sm-2 bg-primary text-gray-100 font-weight-bold'>".$sum_fcf."</div>";
        	echo "</div>";

        	// echo array_sum($data_ocf);
 
			?>
		</div>
	</div>

</div>