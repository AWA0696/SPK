<div class="container-fluid">
	
<?php
if(!$this->input->post('tahun'))
{
    $tahun = date('Y');
}
else 
{
    $tahun = $this->input->post('tahun');
}

?>

<h1 class="h3 mb-4 text-gray-800">Laporan Cashflow Tahun: <?= $tahun ?></h1>
<a href="<?= base_url('Akuntan/cashflow') ?>" class="btn btn-primary btn-icon-split">
    <span class="icon text-white-50">        
        <i class="fas fa-angle-double-left"></i>
    </span>
    <span class="text">KEMBALI</span>
</a>

<div class="card shadow mt-2">	
        
    <div class="card-header bg-primary">
        <h6 class="m-0 font-weight-bold text-gray-100">Laporan Cashflow </h6>
    </div>

    <div class="card-body">
        <div class="row">
            
        </div>
        <?php 
        $bulan = array(
            '1' => 'Januari',
            '2' => 'Februari',
            '3' => 'Maret',
            '4' => 'April',
            '5' => 'Mei',
            '6' => 'Juni',
            '7' => 'Juli',
            '8' => 'Agustus',
            '9' => 'September',
            '10' => 'Oktober',
            '11' => 'November',
            '12' => 'Desember'
        );

        // penambahan inisialisasi data.
        // $this->load->model("Model_init");
        // $init_cf = $this->Model_init->getInitCashflow();

        $this->load->model("Cashflow");
        // $cashflow = $this->Model_Cash_Flow->laporanCashFlow($tahun, $bulan);

        if(!$this->input->post('tahun'))
        {
            $tahun = date('Y');
        }
        else 
        {
            $tahun = $this->input->post('tahun');
        }

        echo "<table class='table table-borderless'>";
        echo "<thead><tr><th>Bulan</th><th>OCF</th><th>ICF</th><th>FCF</th></thead>";
        $total_cf[0] = 0;
        $total_cf[1] = 0;
        $total_cf[2] = 0;        
        
        foreach(array_keys($bulan) as $bl)
        {
            
            echo "<tr>"; 
            echo "<td>".$bulan[$bl]."</td>";  
            $cashflow = $this->Cashflow->cashflowByMonthYear($bl, $tahun);
            if(!$cashflow)
            {
                echo "<td>Rp. 0</td>";
                echo "<td>Rp. 0</td>";
                echo "<td>Rp. 0</td>";
            }

            $i = 0;
            $total_cf_temp[0] = 0;
            $total_cf_temp[1] = 0;
            $total_cf_temp[2] = 0;

            foreach($cashflow as $cf)
            {    
                
                echo "<td>".$this->pitih->formatrupiah($cf->jumlah)."</td>";
                $total_cf_temp[$i] = $cf->jumlah; 
                $i = $i + 1;                
            }   

            $cnt = count($cashflow);
            if(($cnt > 0) and ($cnt < 3))
            {
                $ulang = 3 - $cnt;
                for($i=0;$i<$ulang;$i++)
                {
                    echo "<td>0</td>";
                }
            }          
            
            echo "</tr>";          

            $total_cf[0] = $total_cf[0] + $total_cf_temp[0];
            $total_cf[1] = $total_cf[1] + $total_cf_temp[1];
            $total_cf[2] = $total_cf[2] + $total_cf_temp[2];

            
        }
        echo "</table>"; 
        // print_r($total_cf);
        
        ?>
    </div>
</div>


</div>