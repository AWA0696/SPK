<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Bayana <sup>kun</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url("Akuntan/index") ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <li class="nav-item">

        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <i class="fas fa-database"></i>
            <span>Data Awal</span>
        </a>
        <div id="collapseOne" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Insialisasi Data:</h6>
                <a class="collapse-item" href="<?= base_url('Akuntan/init_balance_sheet') ?>">Balance Sheet</a>
                <a class="collapse-item" href="<?= base_url('Akuntan/init_income_statement') ?>">Income Statement</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Operasi
    </div>

    <li class="nav-item">
        <!-- <a class="nav-link" href="<?= base_url('Akuntan/input') ?>">
                    <i class="far fa-clipboard"></i>
                    <span>Transaksi</span></a> -->
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
            <i class="far fa-clipboard"></i>
            <span>Transaksi</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Menu Transaksi:</h6>
                <a class="collapse-item" href="<?= base_url('Akuntan/index') ?>">Input</a>
                <a class="collapse-item" href="<?= base_url('Akuntan/transaksi') ?>">Kelola</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Akuntan/jurnal_umum') ?>">
            <i class="fas fa-journal-whills"></i>
            <span>Jurnal Umum</span></a>

    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Akuntan/cashflow') ?>">
            <i class="fas fa-money-bill-alt"></i>
            <span>Cashflow Analysis</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Akuntan/balance_sheet') ?>">
            <i class="fas fa-balance-scale"></i>
            <span>Balance Sheet</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Akuntan/income_statement') ?>">
            <i class="fas fa-hand-holding-usd"></i>
            <span>Income Statement</span></a>
    </li>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Navigasi
    </div>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Auth/change_password') ?>">
            <i class="fas fa-key"></i>
            <span>Ganti Password</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Auth/logout') ?>">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>