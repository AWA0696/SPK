<?php
// persiapkan data:
$sub_akun_bs = array();
$balance_s = array();

// foreach($sub_akun as $s_ak)
// {
// 	$found = 0;
// 	foreach($balance_sheet as $bs)
// 	{
// 		if($bs->id_sub_akun == $s_ak->id)
// 		{			
// 			array_push($sub_akun_bs, array('id_sub_akun' => $bs->id_sub_akun, 'id_akun' => $bs->id_akun, 'nama_sub_akun' => $bs->nama_sub_akun, 'jumlah' => $bs->sum_sub_akun, 'jenis' => $s_ak->jenis));
// 			$found = 1;
// 			break;	
// 		}
		
// 	}
// 	if($found < 1) // data tidak ditemukan:
// 	{
// 		array_push($sub_akun_bs, array('id_sub_akun' => $s_ak->id, 'id_akun' => $s_ak->id_akun, 'nama_sub_akun' => $s_ak->nama, 'jumlah' => 0, 'jenis' => $s_ak->jenis));
// 	}
// }

// format data ke dalam array. 

foreach($sub_akun as $s_ak)
{
	array_push($sub_akun_bs, array('id_sub_akun' => $s_ak->id, 'id_akun' => $s_ak->id_akun, 'nama_sub_akun' => $s_ak->nama, 'jumlah' => 0, 'jenis' => $s_ak->jenis));
}

// update jumlah:
foreach($sub_akun_bs as $sabs)
{
	// akun debet
	foreach($sum_akun_debet as $ak_d)
	{
		if($ak_d->id_sub_akun == $sabs["id_sub_akun"])  
		{
			$sabs['jumlah'] = $sabs['jumlah'] + $ak_d->jumlah;
			// echo $sabs['jumlah'];
			break;			
		}
	}

	// akun kredit
	foreach($sum_akun_kredit as $ak_k)
	{
		if($ak_k->id_sub_akun == $sabs["id_sub_akun"])  
		{
			$sabs['jumlah'] = $sabs['jumlah'] - $ak_k->jumlah;
			// echo $sabs['jumlah'];
			break;			
		}
	}

	// print_r($sabs);
	array_push($balance_s, $sabs);
}

// print_r($balance_s);
// return true;


?>
<div class="container-fluid">
	<div class="card shadow">
		<div class="card-header bg-primary">
			<h6 class="m-0 font-weight-bold text-gray-100">Balance Sheet</h6>
		</div>
		<div class="card-body">
			<div class="row">
			<div class="col-lg-6">
				<div class="card shadow">
					<div class="card-header bg-primary">
						<h6 class="m-0 font-weight-bold text-gray-100">Aset</h6>
					</div>
					<div class="card-body">
						<?php
						$jumlah_aset = 0;
						foreach($balance_s as $sabs)
						{
							if($sabs['jenis'] == 1) // aset
							{
								if($sabs['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sabs['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sabs['jumlah']);}

								echo "<div class='row'><div class='col-lg-7 offset-1'>".$sabs['nama_sub_akun']."</div><div class='col-lg-4'>".$angka."</div></div>";
								$jumlah_aset += $sabs['jumlah'];
							}														
						}
						?>						
					</div>
				</div>

			</div>	
			<div class="col-lg-6">
				<div class="card shadow">
					<div class="card-header bg-primary">
						<h6 class="m-0 font-weight-bold text-gray-100">Liabilities</h6>
					</div>
					<div class="card-body">
						<?php
						$jumlah_liabilities = 0;
						foreach($balance_s as $sabs)
						{
							if($sabs['jenis'] == 2) // liability
							{
								
								if($sabs['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sabs['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sabs['jumlah']);}

								echo "<div class='row'><div class='col-lg-7 offset-1'>".$sabs['nama_sub_akun']."</div><div class='col-lg-4'>".$angka."</div></div>";
								$jumlah_liabilities += $sabs['jumlah'];
							}							
						}
						?>
					</div>
				</div>
				<div class="card shadow mt-2">
					<div class="card-header bg-primary">
						<h6 class="m-0 font-weight-bold text-gray-100">Equity</h6>
					</div>
					<div class="card-body">
						<?php
						$jumlah_owner_equity = 0;
						foreach($balance_s as $sabs)
						{
							if($sabs['jenis'] == 3) // owner equity
							{
								if($sabs['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sabs['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sabs['jumlah']);}

								echo "<div class='row'><div class='col-lg-7 offset-1'>".$sabs['nama_sub_akun']."</div><div class='col-lg-4'>".$angka."</div></div>";
								$jumlah_owner_equity += $sabs['jumlah'];
							}							
						}
						?>
					</div>
				</div>
			</div>
			</div>	

			<div class="row mt-2">
				<div class="col-lg-6">
					
					<div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Jumlah Aset</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $this->pitih->formatrupiah($jumlah_aset) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>	
				<div class="col-lg-6">
					
					<div class="card border-left-danger shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Total Liability & Owner Equity:</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $this->pitih->formatrupiah($jumlah_liabilities + $jumlah_owner_equity) ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>			
			</div>		
		</div>
	</div>
</div>