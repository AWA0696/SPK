<?php
$sub_akun_is = array();
$sub_akun_is_init = array();
$income_s = array();
// foreach($sub_akun as $s_ak)
// {
// 	$found = 0;
// 	foreach($income_statement as $is)
// 	{
// 		if($is->id_sub_akun == $s_ak->id)
// 		{			
// 			array_push($sub_akun_is, array('id_sub_akun' => $is->id_sub_akun, 'id_akun' => $is->id_akun, 'nama_sub_akun' => $is->nama_sub_akun, 'nama_akun' => $s_ak->nama_akun, 'jumlah' => $is->sum_sub_akun, 'jenis' => $s_ak->jenis));
// 			$found = 1;
// 			break;	
// 		}
		
// 	}
// 	if($found < 1) // data tidak ditemukan:
// 	{
// 		array_push($sub_akun_is, array('id_sub_akun' => $s_ak->id, 'id_akun' => $s_ak->id_akun, 'nama_sub_akun' => $s_ak->nama, 'nama_akun' => $s_ak->nama_akun, 'jumlah' => 0, 'jenis' => $s_ak->jenis));
// 	}
// }

foreach($sub_akun as $s_ak)
{
	array_push($sub_akun_is, array('id_sub_akun' => $s_ak->id, 'id_akun' => $s_ak->id_akun, 'nama_sub_akun' => $s_ak->nama, 'jumlah' => 0, 'sum_debet' => 0, 'sum_kredit' => 0, 'jenis' => $s_ak->jenis, 'dk' => 0));
}

// +++++++++++++++++++++++++++++++++++++ init data:
foreach($sub_akun_is as $sais)
{
	foreach($init_debet as $in_deb)
	{
		if($sais['id_sub_akun'] == $in_deb->id_sub_akun)
		{
			$sais['sum_debet'] = $sais['sum_debet'] + $in_deb->jumlah;
			break;
		}
	}

	foreach($init_kredit as $in_kre)
	{
		if($sais['id_sub_akun'] == $in_kre->id_sub_akun)
		{
			$sais['sum_kredit'] = $sais['sum_kredit'] + $in_kre->jumlah;
			break;
		}
	}

	array_push($sub_akun_is_init, $sais);
}
// ++++++++++++++++++++++++++++++++++++++ End init.


// update jumlah:
foreach($sub_akun_is_init as $sais)
{
	// akun debet
	foreach($sum_akun_debet as $ak_d)
	{
		if($ak_d->id_sub_akun == $sais["id_sub_akun"])  
		{
			$sais['jumlah'] = $sais['jumlah'] + $ak_d->jumlah;
			$sais['sum_debet'] = $sais['sum_debet'] + $ak_d->jumlah;
			$sais['dk'] = 1; // debet 1, kredit 0
			// echo $sais['jumlah'];
			break;			
		}
	}

	// akun kredit
	foreach($sum_akun_kredit as $ak_k)
	{
		if($ak_k->id_sub_akun == $sais["id_sub_akun"])  
		{
			$sais['jumlah'] = $sais['jumlah'] - $ak_k->jumlah;
			$sais['sum_kredit'] = $sais['sum_kredit'] + $ak_k->jumlah;			
			$sais['dk'] = 0;
			// echo $sais['jumlah'];
			break;			
		}
	}

	// print_r($sais);
	array_push($income_s, $sais);
}

// print_r($income_s);
// return true;

?>

<div class="container-fluid">
	<div class="card shadow">
		<div class="card-header bg-primary">
			<h6 class="m-0 font-weight-bold text-gray-100">Income Statement</h6>
		</div>
		<div class="card-body">
			<?php
			$total_gross_profit = 0;
			// foreach($income_s as $sais)
			// {
			// 	if($sais['jenis'] == "1") // gross profit
			// 	{
			// 		if($sais['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sais['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sais['jumlah']);}

			// 		echo "<div class='row'>";
			// 		echo "<div class='col-lg-4 offset-4'>".$sais['nama_sub_akun']."</div>";
			// 		echo "<div class='col-lg-2'>".$angka."</div>";
			// 		echo "</div>";
			// 		$total_gross_profit += $sais['jumlah'];
			// 	}
			// }

			// tampilkan data secara hardcoded:

			// sales 
			foreach($income_s as $sais)
			{
				if($sais['id_akun'] == 1)
				{
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) * -1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah * -1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2 offset-2'>".$angka."</div>";
					echo "</div>";
					$total_gross_profit += $jumlah;
				}
			}

			// other income:
			foreach($income_s as $sais)
			{
				if($sais['id_akun'] == 2)
				{
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) * -1 ;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah * -1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2 offset-2'>".$angka."</div>";
					echo "</div>";
					$total_gross_profit += $jumlah;
				}
			}

			// cost of good sold
			foreach($income_s as $sais)
			{
				if($sais['id_akun'] == 3)
				{
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) * -1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah * -1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2'>".$angka."</div>";
					echo "</div>";
					$total_gross_profit += $jumlah;
				}
			}


			if($total_gross_profit < 0){$angka = '('.$this->pitih->formatrupiah(($total_gross_profit*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_gross_profit);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>Gross Profit</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// operating expense
			$total_operating_expense = 0;
			// foreach($income_s as $sais)
			// {
			// 	if($sais['jenis'] == "2") 
			// 	{
			// 		if($sais['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sais['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sais['jumlah']);}

			// 		echo "<div class='row'>";
			// 		echo "<div class='col-lg-4 offset-4'>".$sais['nama_sub_akun']."</div>";
			// 		echo "<div class='col-lg-2'>".$angka."</div>";
			// 		echo "</div>";
			// 		$total_operating_expense += $sais['jumlah'];
			// 	}
			// }

			// operating expense
			foreach($income_s as $sais)
			{
				if($sais['id_akun'] == 4)
				{
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) *-1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah *-1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2'>".$angka."</div>";
					echo "</div>";
					$total_operating_expense += $jumlah;
				}
			}


			if($total_operating_expense < 0){$angka = '('.$this->pitih->formatrupiah(($total_operating_expense*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_operating_expense);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>Operating Expense</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// ebitda
			$total_ebitda = $total_gross_profit + $total_operating_expense;

			if($total_ebitda < 0){$angka = '('.$this->pitih->formatrupiah(($total_ebitda*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_ebitda);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>EBITDA</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// ebit
			$total_ebit = 0;
			foreach($income_s as $sais)
			{
				if($sais['jenis'] == "3") 
				{
					// if($sais['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sais['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sais['jumlah']);}

					// echo "<div class='row'>";
					// echo "<div class='col-lg-4 offset-4'>".$sais['nama_sub_akun']."</div>";
					// echo "<div class='col-lg-2'>".$angka."</div>";
					// echo "</div>";
					// $total_ebit += $sais['jumlah'];

					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) *-1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah *-1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2'>".$angka."</div>";
					echo "</div>";
					$total_ebit += $jumlah;
				}
			}
			$total_ebit = $total_ebit + $total_ebitda;

			if($total_ebit < 0){$angka = '('.$this->pitih->formatrupiah(($total_ebit*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_ebit);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>EBIT</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// ebt
			$total_ebt = 0;
			foreach($income_s as $sais)
			{
				if($sais['jenis'] == "4") 
				{

					// if($sais['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sais['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sais['jumlah']);}

					// echo "<div class='row'>";
					// echo "<div class='col-lg-4 offset-4'>".$sais['nama_sub_akun']."</div>";
					// echo "<div class='col-lg-2'>".$angka."</div>";
					// echo "</div>";
					// $total_ebt += $sais['jumlah'];
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) *-1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah *-1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2'>".$angka."</div>";
					echo "</div>";
					$total_ebt += $jumlah;

				}
			}
			$total_ebt = $total_ebt + $total_ebit;

			if($total_ebt < 0){$angka = '('.$this->pitih->formatrupiah(($total_ebt*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_ebt);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>EBT</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// net profit			
			$total_net_profit = 0;
			foreach($income_s as $sais)
			{
				if($sais['jenis'] == "5") 
				{
					// if($sais['jumlah'] < 0){$angka = '('.$this->pitih->formatrupiah(($sais['jumlah']*-1)).')';}else{$angka = $this->pitih->formatrupiah($sais['jumlah']);}

					// echo "<div class='row'>";
					// echo "<div class='col-lg-4 offset-4'>".$sais['nama_sub_akun']."</div>";
					// echo "<div class='col-lg-2'>".$angka."</div>";
					// echo "</div>";
					// $total_net_profit += $sais['jumlah'];
					$jumlah = ($sais['sum_debet'] - $sais['sum_kredit']) *-1;
					if($jumlah < 0)
					{
						$angka = '('.$this->pitih->formatrupiah(($jumlah *-1)).')';
					}
					else
					{
						$angka = $this->pitih->formatrupiah($jumlah);
					}

					echo "<div class='row'>";
					echo "<div class='col-lg-4 offset-4'><a href='".base_url('Akuntan/history/').$sais['id_sub_akun']."/2"."'>".$sais['nama_sub_akun']."</a></div>";
					echo "<div class='col-lg-2'>".$angka."</div>";
					echo "</div>";
					$total_net_profit += $jumlah;
				}
			}
			$total_net_profit = $total_net_profit + $total_ebt;

			if($total_net_profit < 0){$angka = '('.$this->pitih->formatrupiah(($total_net_profit*-1)).')';}else{$angka = $this->pitih->formatrupiah($total_net_profit);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>Net Profit</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// zakat
			$zakat = (($zakat_debet - $zakat_kredit) *-1);
			if($zakat < 0){$angka = '('.$this->pitih->formatrupiah(($zakat*-1)).')';}else{$angka = $this->pitih->formatrupiah($zakat);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4'><strong>Zakat</strong></div>";
			echo "<div class='col-lg-2 offset-6'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			// net profit after zakat
			$net_profit_after_zakat = $total_net_profit + $zakat;

			if($net_profit_after_zakat < 0){$angka = '('.$this->pitih->formatrupiah(($net_profit_after_zakat*-1)).')';}else{$angka = $this->pitih->formatrupiah($net_profit_after_zakat);}

			echo "<div class='row'>";
			echo "<div class='col-lg-4 h5 mb-0 font-weight-bold text-gray-800'><strong>Earnings</strong></div>";
			echo "<div class='col-lg-2 offset-6 border-left-success h5 mb-0 font-weight-bold text-gray-800'>".$angka."</div>";
			echo "</div>";
			echo "<hr>";

			?>
		</div>
	</div>
</div>