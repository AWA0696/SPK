<div class="container-fluid">

    <div class="card shadow">
        <div class="card-header bg-primary">
            <h6 class="m-0 font-weight-bold text-gray-100">Saldo Awal Income Statement</h6>
        </div>
        <div class="card-body">


            <?php
            
            $sub_akun = $this->Akun->getIsAkun();
            $data_debet = $this->Init->getInitIsDebet();
            $data_kredit = $this->Init->getInitIsKredit();

            echo "<form method='post' class='form-horizontal'  action='init_income_statement'>";

            foreach ($sub_akun as $sa) {

                $debet = "";
                foreach($data_debet as $d_deb)
                {
                    if($sa->id == $d_deb->id_sub_akun)
                    {
                        $debet = $this->pitih->formatrupiah($d_deb->jumlah);
                        break; 
                    }
                }

                $kredit = "";
                foreach($data_kredit as $d_kre)
                {
                    if($sa->id == $d_kre->id_sub_akun)
                    {
                        $kredit = $this->pitih->formatrupiah($d_kre->jumlah);
                        break; 
                    }
                }

                echo "<div class='row'>";
                echo "<div class='col-sm-2'>";
                echo "<label class='col-form-label' for='" . $sa->id . "'>$sa->nama";
                echo "</div>";
                echo "<div class='col-sm-4'>";
                echo "<input type='text' class='form-control angka_rupiah' placeholder='Debet' name='d" . $sa->id . "' id='" . $sa->id . "' value='".$debet."'> </div>";
                echo "<div class='col-sm-4'>";
                echo "<input type='text' class='form-control angka_rupiah' placeholder='Kredit' name='k" . $sa->id . "' id='" . $sa->id . "' value='".$kredit."'> </div>";
                echo "<div class='col-sm-2'><a href='".base_url('Akuntan/del_is_init/').$sa->id."' class='btn btn-danger btn-icon-split btn-sm'><span class='icon text-white-50'><i class='far fa-minus-square'></i></span> <span class='text'>HAPUS</span></a></div>";
                echo "</div>";
                echo "<br>";
            }

            // echo "<input type='submit' class='btn btn-primary' value='submit'>";
            ?>
            <div class="row mb-3">
                <div class="col-sm-2">
                    <button type="submit" name="submit" class="btn btn-primary btn-icon-split">
                        <span class="icon text-white-50">
                            <i class="fas fa-save"></i>
                        </span>
                        <span class="text">
                            SIMPAN
                        </span>
                        
                    </button>
                </div>                              
            </div>
            <?php
            echo "</form>";

            ?>


        </div>
    </div>

</div>