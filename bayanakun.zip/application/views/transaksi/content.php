<div class="container-fluid">
	<div class="card shadow">
		<div class="card-header bg-primary">
			<h6 class="m-0 font-weight-bold text-gray-100">Manajemen Transaksi</h6>
		</div>
		<div class="card-body">
			<div class="row">
				<div class="col-lg-3 bg-primary m-0 font-weight-bold text-gray-100 border-right py-1">Tanggal</div>
				<div class="col-lg-6 bg-primary m-0 font-weight-bold text-gray-100 border-right py-1">Transaksi</div>
				<div class="col-lg-3 bg-primary m-0 font-weight-bold text-gray-100 border-right py-1">Operasi</div>
			</div>
			<?php
			foreach ($transaksi as $tr) {
				echo "<div class='row mt-1'>";
				echo "<div class='col-lg-3' id='ta" . $tr->id . "'>" . $tr->tanggal . "</div>";
				echo "<div class='col-lg-6' id='tra" . $tr->id . "'>" . $tr->transaksi . "</div>";
				echo "<div class='col-lg-3'>";
				// echo '<a class="btn btn-warning btn-icon-split btn-sm mr-1"><span class="icon text-white-50"><i class="fas fa-edit"></i></span><span class="text">Edit</span></a>';
				echo "<button onclick='del_transaksi(" . $tr->id .  ",`" . $tr->transaksi . "`)' class='btn btn-danger btn-icon-split btn-sm'><span class='icon text-white-50'><i class='fas fa-trash-alt'></i></span><span class='text'>Delete</span></button>";
				echo "</div>";
				echo "</div>";
			}
			?>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Konfirmasi penghapusan.</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<p>Yakin menghapus transaksi ini: </p>
				<p id="teks_transaksi" class="font-weight-bold"></p>
				<form action="<?= base_url("Akuntan/request_hapus_transaksi") ?>" method="post">
					<input type="hidden" name="id_transaksi_delete" id="id_transaksi_delete">
					<input type="hidden" name="nama_transaksi_delete" id="nama_transaksi_delete">
					<input type="hidden" name="jumlah_transaksi_delete" id="jumlah_transaksi_delete">
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-danger btn-icon-split btn-sm"><span class="icon text-white-50"><i class="fas fa-trash-alt"></i></span><span class="text">Delete</span></button>
				</form>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

			</div>
		</div>

	</div>
</div>