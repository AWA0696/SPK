<script>

function del_transaksi(id_transaksi){
	// console.log($("#tra"+id_transaksi).text());
	$("#teks_transaksi").text($("#tra"+id_transaksi).text());
	$("#id_transaksi_delete").val(id_transaksi);
	$("#myModal").modal('show');
}

</script>