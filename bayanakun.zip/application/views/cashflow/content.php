<div class="container-fluid">
	<?php
	// persiapkan data:
	// $ocf = 0;
	// foreach($rekap_cashflow as $r_cf)
	// {
	// 	if($r_cf[''])
	// }

// print_r($rekap_cashflow);

	?>

	<div class="card shadow">
	<div class="card-header bg-primary">
		<h6 class="m-0 font-weight-bold text-gray-100">Cashflow Analysis</h6>
	</div>
	<div class="card-body">

	<div class="row">
		<div class="col-sm-6">
			<form method="post" action="<?= base_url("Akuntan/cashflow_pertahun") ?>">
				<div class="form-group row">
					<label for="tahun" class="col-form-label">Input tahun</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="tahun">
					</div>
					<div class="col-sm-3">
						<!-- <input type="submit" value="Cari" class="btn btn-primary btn-sm form-control "> -->
						<button type="submit" class="btn btn-primary btn-icon-split">
							<span class="icon text-white-50">
                				<i class="fas fa-search"></i>
                			</span>
                			<span class="text">
                				CARI
                			</span>
						</button>
					</div>			
					
				</div>				
			</form>			
		</div>
	</div>

	<div class="row mt-2">
		<table class="table table-borderless">
			<thead>
				<tr class="bg-primary m-0 font-weight-bold text-gray-100">
					<th class="border-right">No</th>
					<th class="border-right">Tanggal</th>
					<th class="border-right">Transaksi</th>
					<th class="border-right">OCF</th>
					<th class="border-right">ICF</th>
					<th>FCF</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$i = 0;				
				foreach($all_cashflow as $cf)
				{
					$i++;
					$ocf = 0;
					$icf = 0;
					$fcf = 0;
					if($cf->tipe==1){$ocf = $cf->jumlah;}
					if($cf->tipe==2){$icf = $cf->jumlah;}
					if($cf->tipe==3){$fcf = $cf->jumlah;}

					if($ocf >= 0){$d_ocf = $this->pitih->formatrupiah($ocf);}else{$d_ocf = "(".$this->pitih->formatrupiah(($ocf * -1)).")";}
	        		if($icf >= 0){$d_icf = $this->pitih->formatrupiah($icf);}else{$d_icf = "(".$this->pitih->formatrupiah(($icf * -1)).")";}
	        		if($fcf >= 0){$d_fcf = $this->pitih->formatrupiah($fcf);}else{$d_fcf = "(".$this->pitih->formatrupiah(($fcf * -1)).")";}

					echo "<tr>";
					echo "<td>".$i."</td>";
					echo "<td>".$cf->tanggal."</td>";
					echo "<td>".$cf->transaksi."</td>";
					echo "<td>".$d_ocf."</td>";
					echo "<td>".$d_icf."</td>";
					echo "<td>".$d_fcf."</td>";
					echo "</tr>";
				}
				?>
			</tbody>
		</table>
	</div>
	</div>
	</div>
</div>